let string = "Hello World";
console.log(string)